
DATA = ''

MODEL_INIT = '/home/tests/checkers/model_init'

MODEL_TRUE = '/home/tests/checkers/model_true'

PRECOND = ''

SPECFEM_DATA = '/home/tests/checkers/specfem2d-d745c542/DATA'

SPECFEM_BIN = '/home/packages/specfem2d-d745c542/bin'

